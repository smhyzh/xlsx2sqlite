#!/usr/bin/env python3

from distutils.core import setup

setup(
    name = 'xlsx2sqlite',
    version = '1.0.0',
    py_modules = ['xlsx2sqlite','xlsxheader','dbopt'],
)